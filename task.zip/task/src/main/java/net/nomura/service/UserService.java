package net.nomura.service;

import net.nomura.entity.User;
import org.springframework.security.core.userdetails.UserDetailsService;

import net.nomura.web.dto.UserRegistrationDto;

public interface UserService extends UserDetailsService{
	User save(UserRegistrationDto registrationDto);
}
